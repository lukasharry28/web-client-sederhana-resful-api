<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Laravel</title>
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@200;600&display=swap" rel="stylesheet">
    <script type="text/javascript" language="javascript">
        function get_book(){
            let xhr = new XMLHttpRequest();
            xhr.open('GET', 'http://localhost:5237/api/Books');
            xhr.send();
            xhr.onload = function(){
                if(xhr.status != 200 && xhr.status != 201){
                    alert(`Error ${xhr.status}: ${xhr.statusText}`);
                }else{
                    let table = document.getElementById("outputTable");
                    data = JSON.parse(xhr.responseText);
                    data.forEach(function(item){
                        var row = document.createElement("tr");

                        var Id = document.createElement("td");
                        Id.textContent = item.Id;
                        row.appendChild(Id);

                        var BookName = document.createElement("td");
                        BookName.textContent = item.BookName;
                        row.appendChild(BookName);

                        var Price = document.createElement("td");
                        Price.textContent = item.Price;
                        row.appendChild(Price);

                        var Category = document.createElement("td");
                        Category.textContent = item.Category;
                        row.appendChild(Category);

                        var Author = document.createElement("td");
                        Author.textContent = item.Author;
                        row.appendChild(Author);

                        table.appendChild(row);
                    });
                }
            };
        }
    </script>
</head>
<body onload="get_book()">
    <div class="flex-center position-ref full-height">
        <!-- Links -->
        <div class="links">
            <a href="https://laravel.com/docs">Docs</a>
            <a href="https://laracasts.com">Laracasts</a>
            <a href="https://laravel-news.com">News</a>
            <a href="https://blog.laravel.com">Blog</a>
            <a href="https://nova.laravel.com">Nova</a>
            <a href="https://forge.laravel.com">Forge</a>
            <a href="https://vapor.laravel.com">Vapor</a>
            <a href="https://github.com/laravel/laravel">GitHub</a>
        </div>
    </div>
    <table id="outputTable" class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Book Name</th>
                <th>Price</th>
                <th>Category</th>
                <th>Author</th>
            </tr>
        </thead>
        <tbody>
            <!-- Data buku di sini -->
        </tbody>
    </table>
</body>
</html>
