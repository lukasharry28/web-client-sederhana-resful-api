<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Movies;

class PageController extends Controller
{
    public function home(){
        return view("home", ["key" => "Home"]);
    }

    public function movies(){
        $movies=Movies::orderBy('id', 'desc')->get();
        return view("Movies", ["key" => "movies", "mv" => $movies]);
    }
}
