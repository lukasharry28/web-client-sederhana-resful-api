@extends('layouts/main')
@section('title', 'Movies')
@section('Movies')
<div class="card"></div>
<div class="card-body">
    <table id="example" class="display" style="width:100%">
        <thead>
            <tr>
                <th>title</th>
                <th>genre</th>
                <th>year</th>
                <th>stposterk</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($mv as $idx => $m)
            <tr>
                <td>{{$t->$idx+1}}</td>
                <td>{{$t->title}}</td>
                <td>{{$t->genre}}</td>
                <td>{{$t->year}}</td>
                <td>{{$t->poster}}</td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection
